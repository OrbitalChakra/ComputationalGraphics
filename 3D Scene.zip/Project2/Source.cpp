
//Richard Pangelinan Module 2 assignment
//Include appropriate libraries
#include <iostream>
#include <cstdlib>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>      // Image loading Utility functions
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <vector>
#include <cmath>
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif
//namespace std
using namespace std;
//namespace for def

namespace {
	int sections = 32;
	const char* const WINDOW_TITLE = "Assignment 2 Richard Pangelinan";
	const int WINDOW_WIDTH = 800;
	const int WINDOW_HEIGHT = 600;
	//need this struct to hold vertices 
	struct GLMesh
	{
		GLuint vao;
		GLuint vbo;
		vector<float> verts;

		GLuint nIndices;
	};
	GLFWwindow* window = nullptr;
	GLMesh gMesh;
	GLuint gProgramId;
	GLuint gKeyLampProgramId;
	GLuint gFillProgramId;
	GLint gTexWrapMode = GL_REPEAT;
	GLuint gTextureId;
	glm::vec2 gUVScale(1.05f, 1.05f);
	glm::vec3 gLightColor(1.0f, 1.0f, 1.0f);
	// Cube and light color
//m::vec3 gObjectColor(0.6f, 0.5f, 0.75f);
	glm::vec3 gObjectColor(1.0f, 1.0f, 1.0f);

	// Light position and scale
	glm::vec3 gLightPosition(1.5f, 0.5f, 3.0f);
	glm::vec3 gLightScale(0.3f);
	float radius = 10.0f;
	float camX = -0.22;
	float camZ = 1.0;
	float camY = 0.0;
	float lastX = 400, lastY = 300;
	float yaw = -90.0f;
	float pitch;
	glm::vec3 cameraFront;
	bool firstMouse = true;
}
//define functions


bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UCreateMesh(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
void URender();
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);
void mouseCallback(GLFWwindow* window, double xpos, double ypos);


//Vertex Shader Program used to color the vertices
const GLchar* vertexShaderSource = GLSL(440,
	layout(location = 0) in vec3 position;
layout(location = 1) in vec3 normal;
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
out vec2 vertexTextureCoordinate;

//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
	gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

	vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

	vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
	vertexTextureCoordinate = textureCoordinate;
}
);


/* Cube Fragment Shader Source Code*/
const GLchar* cubeFragmentShaderSource = GLSL(440,

	in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;

void main()
{
	/*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

	//Calculate Ambient lighting*/
	float ambientStrength = 0.10f; // Set ambient or global lighting strength
	vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

	//Calculate Diffuse lighting*/
	vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
	vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
	float impact = max(dot(norm, lightDirection), 1.0f);// Calculate diffuse impact by generating dot product of normal and light
	vec3 diffuse = impact * lightColor; // Generate diffuse light color

	//Calculate Specular lighting*/
	float specularIntensity = 0.25f; // Set specular light strength
	float highlightSize = 16.0f; // Set specular highlight size
	vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
	vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
	//Calculate specular component
	float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
	vec3 specular = specularIntensity * specularComponent * lightColor;

	// Texture holds the color to be used for all three components
	vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

	// Calculate phong result
	vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

	fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);
/* Lamp Shader Source Code*/
const GLchar* lampVertexShaderSource = GLSL(440,

	layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

		//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
	gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
}
);


/* Fragment Shader Source Code*/
const GLchar* lampFragmentShaderSource = GLSL(440,

	out vec4 fragmentColor; // For outgoing lamp color (smaller cube) to the GPU

void main()
{
	fragmentColor = vec4(0.0f, 1.0f, 1.0f, 1.0f); // Set color to white (1.0f,1.0f,1.0f) with alpha 1.0
}
);

void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
	for (int j = 0; j < height / 2; ++j)
	{
		int index1 = j * width * channels;
		int index2 = (height - 1 - j) * width * channels;

		for (int i = width * channels; i > 0; --i)
		{
			unsigned char tmp = image[index1];
			image[index1] = image[index2];
			image[index2] = tmp;
			++index1;
			++index2;
		}
	}
}

int main(int argc, char* argv[]) {
	if (!UInitialize(argc, argv, &window))
		return EXIT_FAILURE;

	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
	glfwSetCursorPosCallback(window, mouseCallback);
	//set background color
	UCreateMesh(gMesh);
	if (!UCreateShaderProgram(vertexShaderSource, cubeFragmentShaderSource, gProgramId))
		return EXIT_FAILURE;
	if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gKeyLampProgramId))
		return EXIT_FAILURE;
	const char* texFilename = "hedge-texture_23-2147625853.jpg";

	if (!UCreateTexture(texFilename, gTextureId)) {
		cout << "Failed to load texture " << texFilename << endl;
		return EXIT_FAILURE;
	}
	glUseProgram(gProgramId);

	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 0);
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

	//render
	while (!glfwWindowShouldClose(window))
	{
		//get input
		UProcessInput(window);
		URender();
		glfwPollEvents();

	}
	UDestroyMesh(gMesh);
	UDestroyTexture(gTextureId);
	UDestroyShaderProgram(gProgramId);
	UDestroyShaderProgram(gKeyLampProgramId);

	exit(EXIT_SUCCESS);
}

void mouseCallback(GLFWwindow* window, double xpos, double ypos) {
	if (firstMouse) {
		lastX = xpos;
		lastY = ypos;
		firstMouse = false;
	}
	float xoffset = xpos - lastX;
	float yoffset = lastY - ypos;
	lastX = xpos;
	lastY = ypos;
	float sensitivity = 0.01f;
	xoffset *= sensitivity;
	yoffset *= sensitivity;
	yaw += xoffset;
	pitch += yoffset;
	if (pitch > 89.0f)
		pitch = 89.0f;
	if (pitch < -89.0f)
		pitch = -89.0f;
	glm::vec3 direction;
	direction.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
	direction.y = sin(glm::radians(pitch));
	direction.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
	cameraFront = glm::normalize(direction);
}
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
	//init and config GLFW
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	* window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return false;
	}
	glfwMakeContextCurrent(*window);
	glfwSetFramebufferSizeCallback(*window, UResizeWindow);

	// GLEW: initialize
	// ----------------
	// Note: if using GLEW version 1.13 or earlier
	glewExperimental = GL_TRUE;
	GLenum GlewInitResult = glewInit();

	if (GLEW_OK != GlewInitResult)
	{
		std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
		return false;
	}
	// Displays GPU OpenGL version
	cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

	return true;
}
void UCreateMesh(GLMesh& mesh) {
	//vertices for mesh
	float radius = 0.3f;
	float radius2 = 0.1f;
	float height = 0.667f;
	float height2 = -0.2f;
	vector<float> verts;

	//Pi for finding points along base
	float pi = 3.14159f;
	//steps for building different sections of the cone
	float sectionStep = 2.0f * pi / sections;
	for (int i = 0; i < sections; i++) {
		verts.insert(verts.end(), { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,  }); //center point of base
		verts.insert(verts.end(), { radius * cos(i * sectionStep), radius * sin(i * sectionStep), 0.0f, 0.0f, 1.0 });//triangle 1 vertex 1 
		verts.insert(verts.end(), { radius * cos((i + 1) * sectionStep), radius * sin((i + 1) * sectionStep), 0.0f, 0.0f, 1.0f  }); //triangle  1 vertex 2
		verts.insert(verts.end(), { radius * sin(i * sectionStep), radius * cos(i * sectionStep), 0.0f, 0.0f, 1.0f }); //triangle 2 vertex 1
		verts.insert(verts.end(), { radius * sin((i + 1) * sectionStep), radius * cos((i + 1) * sectionStep), 0.0f,  0.0f, 1.0f }); //triangle 2 vertex
		verts.insert(verts.end(), { 0.0f, 0.0f, height, 0.0f, 1.0f }); //tip of cone
	}
	for (int i = 0; i < sections; i++) {
			verts.insert(verts.end(), { 0.0f, 0.0f, 0.0f, 1.0f, 1.0f }); //center of object base
			verts.insert(verts.end(), { radius2 * cos(i * sectionStep), radius2 * sin(i * sectionStep), -height2, 0.0f, 1.0f }); //vertex 
			verts.insert(verts.end(), { radius2 * cos((i + 1) * sectionStep), radius2 * sin((i + 1) * sectionStep), -height2, 0.0f, 1.0f });//vertex
	}
	for (int i = 0; i < sections; i++) {
		verts.insert(verts.end(), { 0.0f, 0.0f, 0.0f, 1.0f, 1.0f });// center of base bottom
		verts.insert(verts.end(), { radius2 * cos(i * sectionStep), radius2 * sin(i * sectionStep), height2, 0.0f, 1.0f }); //triangle vertex 1
		verts.insert(verts.end(), { radius2 * cos((i + 1) * sectionStep), radius2 * sin((i + 1) * sectionStep), height2, 0.0f, 1.0f }); //triangle vertex 2
	}
	for (int i = 0; i < sections; i++) {
		verts.insert(verts.end(), { 0.9f, -0.9f, 0.0f, 0.0f, 0.0f, }); //center point of base
		verts.insert(verts.end(), { radius * cos(i * sectionStep) +0.9f, radius * sin(i * sectionStep) -0.9f, 0.0f, 0.0f, 1.0 });//triangle 1 vertex 1 
		verts.insert(verts.end(), { radius * cos((i + 1) * sectionStep) +0.9f, radius * sin((i + 1) * sectionStep) -0.9f, 0.0f, 0.0f, 1.0f }); //triangle  1 vertex 2
		verts.insert(verts.end(), { radius * sin(i * sectionStep) +0.9f, radius * cos(i * sectionStep) - 0.9f, 0.0f, 0.0f, 1.0f }); //triangle 2 vertex 1
		verts.insert(verts.end(), { radius * sin((i + 1) * sectionStep) + 0.9f, radius * cos((i + 1) * sectionStep) -0.9f, 0.0f,  0.0f, 1.0f }); //triangle 2 vertex
		verts.insert(verts.end(), { 0.9f, -0.9f, height, 0.0f, 1.0f }); //tip of cone
	}
	for (int i = 0; i < sections; i++) {
		verts.insert(verts.end(), { +0.9f, -0.9f, 0.0f, 1.0f, 1.0f }); //center of object base
		verts.insert(verts.end(), { radius2 * cos(i * sectionStep) +0.9f, radius2 * sin(i * sectionStep) -0.9f, 0.0f, 0.0f, 1.0f }); //vertex 
		verts.insert(verts.end(), { radius2 * cos((i + 1) * sectionStep) +0.9f, radius2 * sin((i + 1) * sectionStep) - 0.9f, 0.0f, 0.0f, 1.0f });//vertex
	}
	for (int i = 0; i < sections; i++) {
		verts.insert(verts.end(), { 0.9f + radius2 * cos(i * sectionStep), -0.9f + radius2 * sin(i * sectionStep),height2, 1.0f, 1.0f });
		verts.insert(verts.end(), { radius2 * cos((i + 1) * sectionStep) + 0.9f, radius2 * sin((i + 1) * sectionStep) - 0.9f, 0.0f, 0.0f, 1.0f });
		verts.insert(verts.end(), { radius2 * cos((i)*sectionStep) + 0.9f, radius2 * sin((i)*sectionStep) - 0.9f, 0.0f, 0.0f, 1.0f });
		verts.insert(verts.end(), { radius2 * sin(i * sectionStep) + 0.9f, radius2 * cos(i * sectionStep) - 0.9f, height2, 0.0f, 1.0f });
		verts.insert(verts.end(), { radius2 * sin((i + 1) * sectionStep) + 0.9f, radius2 * cos((i + 1) * sectionStep) - 0.9f, 0.0f, 0.0f, 1.0f });
		verts.insert(verts.end(), { radius2 * sin((i + 1) * sectionStep) + 0.9f, radius2 * cos((i + 1) * sectionStep) - 0.9f, 0.0f, 0.0f, 1.0f });
	}

	for (int i = 0; i < sections; i++) {
		verts.insert(verts.end(), { 0.9f, 0.9f, 0.0f, 0.0f, 0.0f, }); //center point of base
		verts.insert(verts.end(), { radius * cos(i * sectionStep) + 0.9f, radius * sin(i * sectionStep) + 0.9f, 0.0f, 0.0f, 1.0 });//triangle 1 vertex 1 
		verts.insert(verts.end(), { radius * cos((i + 1) * sectionStep) + 0.9f, radius * sin((i + 1) * sectionStep)+ 0.9f, 0.0f, 0.0f, 1.0f }); //triangle  1 vertex 2
		verts.insert(verts.end(), { radius * sin(i * sectionStep) + 0.9f, radius * cos(i * sectionStep) + 0.9f, 0.0f, 0.0f, 1.0f }); //triangle 2 vertex 1
		verts.insert(verts.end(), { radius * sin((i + 1) * sectionStep) + 0.9f, radius * cos((i + 1) * sectionStep) + 0.9f, 0.0f,  0.0f, 1.0f }); //triangle 2 vertex
		verts.insert(verts.end(), { 0.9f, 0.9f, height, 0.0f, 1.0f }); //tip of cone
	}
	for (int i = 0; i < sections; i++) {
		verts.insert(verts.end(), { 0.9f, 0.9f, 0.0f, 1.0f, 1.0f }); //center of object base
		verts.insert(verts.end(), { radius2 * cos(i * sectionStep) + 0.9f, radius2 * sin(i * sectionStep) + 0.9f, 0.0f, 0.0f, 1.0f }); //vertex 
		verts.insert(verts.end(), { radius2 * cos((i + 1) * sectionStep) + 0.9f, radius2 * sin((i + 1) * sectionStep) + 0.9f, 0.0f, 0.0f, 1.0f });//vertex
	}
	//for (int i = 0; i < sections; i++) {
	//	verts.insert(verts.end(), { +0.9f, +0.9f, height2, 1.0f, 1.0f });// center of base bottom
	//	verts.insert(verts.end(), { radius2 * cos(i * sectionStep) + 0.9f, radius2 * sin(i * sectionStep) + 0.9f, height2, 0.0f, 1.0f }); //triangle vertex 1
	//	verts.insert(verts.end(), { radius2 * cos((i + 1) * sectionStep) + 0.9f, radius2 * sin((i + 1) * sectionStep) + 0.9f, height2, 0.0f, 1.0f }); //triangle vertex 2

	//}
	for (int i = 0; i < sections; i++) {
		verts.insert(verts.end(), { 0.9f + radius2*cos(i*sectionStep), 0.9f + radius2*sin(i*sectionStep),height2, 1.0f, 1.0f });
		verts.insert(verts.end(), { radius2 * cos((i+1) * sectionStep) + 0.9f, radius2 * sin((i+1) * sectionStep) + 0.9f, 0.0f, 0.0f, 1.0f });
		verts.insert(verts.end(), { radius2 * cos((i) * sectionStep) + 0.9f, radius2 * sin((i) * sectionStep) + 0.9f, 0.0f, 0.0f, 1.0f });
		verts.insert(verts.end(), { radius2 * sin(i * sectionStep) + 0.9f, radius2 * cos(i * sectionStep) + 0.9f, height2, 0.0f, 1.0f });
		verts.insert(verts.end(), { radius2 * sin((i + 1) * sectionStep) + 0.9f, radius2 * cos((i + 1) * sectionStep) + 0.9f, 0.0f, 0.0f, 1.0f });
		verts.insert(verts.end(), { radius2 * sin((i + 1) * sectionStep) + 0.9f, radius2 * cos((i + 1) * sectionStep) + 0.9f, 0.0f, 0.0f, 1.0f });
	}

	verts.insert(verts.end(), { -2.0f, 0.6f, -0.2f, 1.0f, 1.0f, //backleft bottom
			-2.0f, 0.6f, 0.1f, 1.0f, 1.0f, //backleft top
			2.0f, 0.6f, -0.2f, 1.0f, 1.0f, //backright bottom
			2.0f, 0.6f, 0.1f, 1.0f, 1.0f, //backright top
			-2.0f, 0.6f, 0.1f, 1.0f, 1.0f, //backleft top
			2.0f, 0.6f, -0.2f, 1.0f, 1.0f, //backright bottom
			-2.0f, 0.45f, -0.2f, 1.0f, 1.0f, //backleft bottom
			-2.0f, 0.45f, 0.1f, 1.0f, 1.0f, //backleft top
			2.0f, 0.45f, -0.2f, 1.0f, 1.0f, //front right bottom
			2.0f, 0.45f, 0.1f, 1.0f, 1.0f, //front right top
			-2.0f, 0.45f, 0.1f, 1.0f, 1.0f, //back right top
			2.0f, 0.45f, -0.2f, 1.0f, 1.0f, //front right bottom
			-2.0f, 0.6f, 0.1f, 1.0f, 1.0f, // back left top
			2.0f, 0.45f, 0.1f, 1.0f, 1.0f, // front right top
			2.0f, 0.6f, 0.1f, 1.0f, 1.0f,  //front left top
			2.0f, 0.45f, 0.1f, 1.0f, 1.0f,  // front right top
			-2.0f, 0.45f, 0.1f, 1.0f, 1.0f, //back right top
			-2.0f, 0.6f, 0.1f, 1.0f, 1.0f   //back left top
			});

	verts.insert(verts.end(), { -2.0f, -0.6f, -0.2f, 1.0f, 1.0f, //backleft bottom
		-2.0f, -0.6f, 0.1f, 1.0f, 1.0f, //backleft top
		2.0f, -0.6f, -0.2f, 1.0f, 1.0f, //backright bottom
		2.0f, -0.6f, 0.1f, 1.0f, 1.0f, //backright top
		-2.0f, -0.6f, 0.1f, 1.0f, 1.0f, //backleft top
		2.0f, -0.6f, -0.2f, 1.0f, 1.0f, //backright bottom
		-2.0f, -0.45f, -0.2f, 1.0f, 1.0f, //backleft bottom
		-2.0f, -0.45f, 0.1f, 1.0f, 1.0f, //backleft top
		2.0f, -0.45f, -0.2f, 1.0f, 1.0f, //front right bottom
		2.0f, -0.45f, 0.1f, 1.0f, 1.0f, //front right top
		-2.0f, -0.45f, 0.1f, 1.0f, 1.0f, //back right top
		2.0f, -0.45f, -0.2f, 1.0f, 1.0f, //front right bottom
		-2.0f, -0.6f, 0.1f, 1.0f, 1.0f, // back left top
		2.0f, -0.45f, 0.1f, 1.0f, 1.0f, // front right top
		2.0f, -0.6f, 0.1f, 1.0f, 1.0f,  //front left top
		2.0f, -0.45f, 0.1f, 1.0f, 1.0f,  // front right top
		-2.0f, -0.45f, 0.1f, 1.0f, 1.0f, //back right top
		-2.0f, -0.6f, 0.1f, 1.0f, 1.0f   //back left top
		});
	verts.insert(verts.end(), { -3.4f,-3.4f,	-0.2f,	0.0f,	1.0f,	//backleft
		 0.0f,	3.4f,	 -0.2f,	0.0f,	1.0f,	//middle
		-3.4f,	3.4f,	 -0.2f,	0.0f,	1.0f, // back right

		-3.4f,	-3.4f,	-0.2f, 	0.0f,	1.0f,	// back left
		 0.0f,	3.4f,	 -0.2f,	0.0f,	1.0f,	// middle
		 0.0f,	-3.4f,	-0.2f, 	0.0f,	1.0f,	// front left

		 0.0f,	-3.4f,	-0.2f, 	0.0f,	1.0f,// front left
		 0.0f,	3.4f,	 -0.2f, 	0.0f,	1.0f,	// middle
		 3.4f,	3.4f,	-0.2f, 	0.0f,	1.0f,	//  front right

		 0.0f,	-3.4f,	-0.2f, 	0.0f,	1.0f,	// middle
		3.4f,	3.4f,	 -0.2f, 	0.0f,	1.0f,	// front right
		 3.4f,	-3.4f,	-0.2f, 	0.0f,	1.0f});	// back right 
	GLuint floatsPerVertex = 3;
	GLuint floatsPerUV = 2;

	mesh.verts = verts;
	mesh.nIndices = mesh.verts.size() / (floatsPerVertex + floatsPerUV);

	verts.clear();
	glGenVertexArrays(1, &mesh.vao);
	glBindVertexArray(mesh.vao);

	glGenBuffers(1, &mesh.vbo);
	glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo);
	glBufferData(GL_ARRAY_BUFFER, sizeof(float) * mesh.verts.size(), &mesh.verts.front(), GL_STATIC_DRAW);

	GLint stride = sizeof(float) * (floatsPerVertex + floatsPerUV);

	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, (void*)0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) *floatsPerUV));
	glEnableVertexAttribArray(2);
};

void UProcessInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);
	else if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)//forward
		camX += 0.01;
	else if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)//backwards
		camX -= 0.01;
	else if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)//right
		camY += 0.01;
	else if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)//left
		camY -= 0.01;
	else if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)//up
		camZ += 0.01;
	else if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)//down
		camZ -= 0.01;
}

void UResizeWindow(GLFWwindow* window, int width, int height)
{
	glViewport(0, 0, width, height);
}

void UDestroyMesh(GLMesh& mesh) {
	//methods to destroy vertex array object
	glDeleteVertexArrays(1, &mesh.vao);
	//methods to destroy vertex buffer object
	glDeleteBuffers(1, &mesh.vbo);
}

bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
	// Compilation and linkage error reporting
	int success = 0;
	char infoLog[512];

	// Create a Shader program object.
	programId = glCreateProgram();

	// Create the vertex and fragment shader objects
	GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
	GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

	// Retrive the shader source
	glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
	glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

	// Compile the vertex shader, and print compilation errors (if any)
	glCompileShader(vertexShaderId); // compile the vertex shader
	// check for shader compile errors
	glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

		return false;
	}

	glCompileShader(fragmentShaderId); // compile the fragment shader
	// check for shader compile errors
	glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
		std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

		return false;
	}

	// Attached compiled shaders to the shader program
	glAttachShader(programId, vertexShaderId);
	glAttachShader(programId, fragmentShaderId);

	glLinkProgram(programId);   // links the shader program
	// check for linking errors
	glGetProgramiv(programId, GL_LINK_STATUS, &success);
	if (!success)
	{
		glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
		std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

		return false;
	}

	glUseProgram(programId);    // Uses the shader program

	return true;
}



void UDestroyShaderProgram(GLuint programId)
{
	glDeleteProgram(programId);
}

void URender()
{
	glEnable(GL_DEPTH_TEST);
	glClearColor(0.1654f, 0.3f, 0.8f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	// 1. Scales the shape down by half of its original size in all 3 dimensions
	glm::mat4 scale = glm::scale(glm::mat4(1.0f), glm::vec3(1.0f,1.0f, 1.0f));

	// 2. Rotates shape by 45 degrees on the z axis
	glm::mat4 xrotation = glm::rotate(glm::mat4(1.0f), glm::radians(180.0f), glm::vec3(1.0f, 0.0f,0.0f));
	glm::mat4 yrotation = glm::rotate(glm::mat4(1.0f), glm::radians(-90.0f), glm::vec3(0.0f, 1.0f, 0.0f));
	glm::mat4 zrotation = glm::rotate(glm::mat4(1.0f), glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.0f));
	// 3. Translates by 0.5 in the y axis
	glm::mat4 translation = glm::translate(glm::mat4(1.0f), glm::vec3(-0.0f, -1.0f,0.0f));

	// Transformations are applied right-to-left order
	glm::mat4 model = translation * xrotation * zrotation * yrotation * scale;

	glm::mat4 view = glm::mat4(1.0f);
	glm::vec3 cameraTarget = glm::vec3(0.0f, -0.4f, 0.0f);
	glm::vec3 cameraPos = glm::vec3(camX, camY, camZ);
	glm::vec3 cameraDirection = glm::normalize(cameraPos - cameraTarget);
	glm::vec3 up = glm::vec3(0.0f, 1.0f, 0.0f);
	glm::vec3 cameraRight = glm::normalize(glm::cross(up, cameraDirection));
	glm::vec3 cameraUp = glm::cross(cameraDirection, cameraRight);
	view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
	glm::mat4 projection = glm::ortho(-5.0f, 5.0f, -5.0f, 5.0f, 2.0f, 0.0f);
	if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)		
		projection = glm::perspective(45.0f, (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
	
		

	glUseProgram(gProgramId);
	GLuint modelLoc = glGetUniformLocation(gProgramId, "model");
	GLuint viewLoc = glGetUniformLocation(gProgramId, "view");
	GLuint projLoc = glGetUniformLocation(gProgramId, "projection");
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

	
	

	GLint objectColorLoc = glGetUniformLocation(gProgramId, "objectColor");
	GLint lightColorLoc = glGetUniformLocation(gProgramId, "lightColor");
	GLint lightPositionLoc = glGetUniformLocation(gProgramId, "lightPos");
	GLint viewPositionLoc = glGetUniformLocation(gProgramId, "viewPosition");

	// Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
	glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
	glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
	glUniform3f(lightPositionLoc, gLightPosition.x, gLightPosition.y, gLightPosition.z);
	GLint UVScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
	glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

	glBindVertexArray(gMesh.vao);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gTextureId);	
	glDrawArrays(GL_TRIANGLES, 0, gMesh.nIndices);
	glUseProgram(gKeyLampProgramId);
	model = glm::translate(glm::mat4(1.0f), gLightPosition) * glm::scale(glm::mat4(1.0f), gLightScale);

	// Reference matrix uniforms from the Lamp Shader program
	modelLoc = glGetUniformLocation(gKeyLampProgramId, "model");
	viewLoc = glGetUniformLocation(gKeyLampProgramId, "view");
	projLoc = glGetUniformLocation(gKeyLampProgramId, "projection");

	

	// Pass matrix data to the Lamp Shader program's matrix uniforms
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));



	glBindVertexArray(0);
	glUseProgram(0);
	glfwSwapBuffers(window);
}

bool UCreateTexture(const char* filename, GLuint& textureId)
{
	int width, height, channels;
	unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
	if (image)
	{
		flipImageVertically(image, width, height, channels);

		glGenTextures(1, &textureId);
		glBindTexture(GL_TEXTURE_2D, textureId);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if (channels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		else if (channels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			cout << "Not implemented to handle image with " << channels << " channels" << endl;
			return false;
		}

		glGenerateMipmap(GL_TEXTURE_2D);

		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		return true;
	}

	// Error loading the image
	return false;
}
void UDestroyTexture(GLuint textureId)
{
	glGenTextures(1, &textureId);
}